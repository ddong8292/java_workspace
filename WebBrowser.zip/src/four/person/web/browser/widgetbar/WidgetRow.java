package four.person.web.browser.widgetbar;

import javafx.scene.layout.HBox;

public class WidgetRow extends HBox{
	public WidgetRow() {
		
	}
}
