package four.person.web.browser.settings.history;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class SettingsHistoryController implements Initializable{

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
